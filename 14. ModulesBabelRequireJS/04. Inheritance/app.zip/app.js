let Entity = require('./Entity');
let Dog = require('./Dog');
let Person = require('./Person');
let Student = require('./Student');

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;

//let dog = new Dog('sharo');
//let person = new Person('pesho', 'haha', dog);
//let student = new Student('kolio', 'kurac', dog, 12);
//console.log(student.saySomething());
