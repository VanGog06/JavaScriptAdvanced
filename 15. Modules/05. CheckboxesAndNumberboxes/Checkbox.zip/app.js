let Checkbox = require('./Checkbox');
let Numberbox = require('./Numberbox');

result.Checkbox = Checkbox;
result.Numberbox = Numberbox;