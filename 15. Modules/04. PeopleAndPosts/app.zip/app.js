let Person = require('./Person');
let Post = require('./Post');

result.Person = Person;
result.Post = Post;